﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Observer.Traditional
{
	public abstract class AbstractObserver
	{
		public abstract void Update();
	}
}

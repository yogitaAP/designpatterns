﻿using System;

namespace Strategy_Before.Domain
{
    public class UnknownOrderShippingMethodException : Exception
    {
    }
}
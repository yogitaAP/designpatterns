﻿using System;

namespace Strategy_After_Variation.Domain
{
    public class UnknownOrderShippingMethodException : Exception
    {
    }
}
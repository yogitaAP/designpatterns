namespace Factory2.Autos
{
    public class NullAuto : IAuto
    {
        public void TurnOn()
        {
            
        }

        public void TurnOff()
        {
            
        }
    }
}
namespace Factory2.Autos
{
    public interface IAuto
    {
        void TurnOn();
        void TurnOff();
    }
}
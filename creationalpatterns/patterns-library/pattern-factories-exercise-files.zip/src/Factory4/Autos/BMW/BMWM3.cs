namespace Factory4.Autos.BMW
{
    public class BMWM3 : BMWBase
    {
        public override string Name
        {
            get { return "BMW M3"; }
        }
    }
}
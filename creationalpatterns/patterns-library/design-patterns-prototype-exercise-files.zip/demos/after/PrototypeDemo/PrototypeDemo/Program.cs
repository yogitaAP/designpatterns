﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PrototypeDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            var complicatedObject = // can't do new


            Console.ReadKey();
        }
    }
}

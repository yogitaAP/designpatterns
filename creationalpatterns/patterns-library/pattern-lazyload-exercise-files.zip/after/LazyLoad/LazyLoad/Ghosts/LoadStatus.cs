namespace LazyLoad.Ghosts
{
    public enum LoadStatus
    {
        Ghost,
        Loading,
        Loaded
    }
}
namespace MVP.Manufacturers.List
{
    public interface IManufacturerListView
    {
        void Show(ManufacturerListVM viewModel);
    }
}

using System;

namespace PS.Auto.Domain
{
    public interface IEntity
    {
        Guid Id { get; }
    }
}
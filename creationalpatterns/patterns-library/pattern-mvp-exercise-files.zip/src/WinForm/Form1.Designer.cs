﻿namespace PS.WinForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.manufacturersListBox = new System.Windows.Forms.ListBox();
            this.titleLabel = new System.Windows.Forms.Label();
            this.sortButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // manufacturersListBox
            // 
            this.manufacturersListBox.FormattingEnabled = true;
            this.manufacturersListBox.Location = new System.Drawing.Point(12, 42);
            this.manufacturersListBox.Name = "manufacturersListBox";
            this.manufacturersListBox.Size = new System.Drawing.Size(235, 420);
            this.manufacturersListBox.TabIndex = 1;
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(13, 13);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(35, 13);
            this.titleLabel.TabIndex = 2;
            this.titleLabel.Text = "label1";
            // 
            // sortButton
            // 
            this.sortButton.Location = new System.Drawing.Point(171, 13);
            this.sortButton.Name = "sortButton";
            this.sortButton.Size = new System.Drawing.Size(75, 23);
            this.sortButton.TabIndex = 3;
            this.sortButton.Text = "sort";
            this.sortButton.UseVisualStyleBackColor = true;
            this.sortButton.Click += new System.EventHandler(this.SortButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(260, 474);
            this.Controls.Add(this.sortButton);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.manufacturersListBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox manufacturersListBox;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Button sortButton;

    }
}


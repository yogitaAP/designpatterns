namespace CompositeDemo
{
    public interface Party
    {
        int Gold { get; set; }
        void Stats();
    }
}
﻿namespace LoggingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Program2.Run(args);
        }
    }
}

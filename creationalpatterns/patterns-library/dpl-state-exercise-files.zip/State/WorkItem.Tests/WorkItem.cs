﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace WorkItem.Tests
{
	[TestClass]
	public class WorkItem
	{
		[TestMethod]
		public void Create()
		{
			
		}
	}
}

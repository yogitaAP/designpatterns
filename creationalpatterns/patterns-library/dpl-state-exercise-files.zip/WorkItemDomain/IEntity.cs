﻿namespace WorkItemDomain
{
	public interface IEntity
	{
		int Id { get; set; }
	}
}